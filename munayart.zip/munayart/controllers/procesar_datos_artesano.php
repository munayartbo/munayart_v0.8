<?php
session_start();
include 'db_connection.php';

// Verificar que el usuario tenga el rol de artesano

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'artesano') {
    echo "<script>
              alert('No tienes el rol de Artesano');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener los datos enviados desde el formulario
$descripcion = $_POST['descripcion'];
$anios_exp = $_POST['anios_exp'];
$cod_comunidad = $_POST['cod_comunidad'];

// Obtener el ID del artesano desde la sesión
$cod_artesano = $_SESSION['user_id'];

// Inicializar la variable de la ruta de la imagen
$imagen_ruta = "";

// Verificar si el archivo fue enviado
if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] == 0) {
    $foto_perfil = $_FILES['foto_perfil'];
    $target_dir = "../views/images/"; // Carpeta donde se guardarán las imágenes de perfil
    $target_file = $target_dir . basename($foto_perfil["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Verificar si el archivo es una imagen real
    $check = getimagesize($foto_perfil["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo "<script>alert('El archivo no es una imagen.'); window.location.href = '../views/completar_datos_artesano.php';</script>";
        $uploadOk = 0;
    }

    // Verificar si ya existe la imagen
    if (file_exists($target_file)) {
        echo "<script>alert('La imagen ya existe.'); window.location.href = '../views/completar_datos_artesano.php';</script>";
        $uploadOk = 0;
    }

    // Limitar el tamaño de la imagen (ej. máximo 5MB)
    if ($foto_perfil["size"] > 5000000) {
        echo "<script>alert('El archivo es demasiado grande.'); window.location.href = '../views/completar_datos_artesano.php';</script>";
        $uploadOk = 0;
    }

    // Permitir solo ciertos formatos de imagen
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" && $imageFileType != "webp") {
        echo "<script>alert('Solo se permiten archivos JPG, JPEG, PNG y GIF.'); window.location.href = '../views/completar_datos_artesano.php';</script>";
        $uploadOk = 0;
    }

    // Verificar si $uploadOk es 0 debido a un error
    if ($uploadOk == 0) {
        echo "<script>alert('Tu archivo no se pudo subir.'); window.location.href = '../views/completar_datos_artesano.php';</script>";
    } else {
        // Si todo está bien, subir la imagen
        if (move_uploaded_file($foto_perfil["tmp_name"], $target_file)) {
            // Guardar la ruta de la imagen en la base de datos
            $imagen_ruta = "../views/images/" . basename($foto_perfil["name"]);
        } else {
            echo "<script>alert('Hubo un error subiendo tu archivo.'); window.location.href = '../views/completar_datos_artesano.php';</script>";
        }
    }
}

// Comprobar si el artesano ya tiene un registro en la base de datos
$sql_check = "SELECT * FROM artesano WHERE CodArtesano = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("i", $cod_artesano);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

// Si ya existe un registro, actualizar los datos. Si no, insertar uno nuevo.
if ($result_check->num_rows > 0) {
    // Actualizar los datos existentes
    if (!empty($imagen_ruta)) {
        $sql_update = "UPDATE artesano SET Descripcion = ?, AniosExp = ?, CodComunidad = ?, Imagen = ? WHERE CodArtesano = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("sissi", $descripcion, $anios_exp, $cod_comunidad, $imagen_ruta, $cod_artesano);
    } else {
        // Si no hay imagen nueva, no actualizamos el campo 'Imagen'
        $sql_update = "UPDATE artesano SET Descripcion = ?, AniosExp = ?, CodComunidad = ? WHERE CodArtesano = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("siii", $descripcion, $anios_exp, $cod_comunidad, $cod_artesano);
    }

    if ($stmt_update->execute()) {
        echo "<script>alert('Datos del artesano actualizados correctamente'); window.location.href = '../views/subir_producto.php';</script>";
    } else {
        echo "<script>alert('Error al actualizar los datos'); window.location.href = '../views/completar_datos_artesano.php';</script>";
    }

    $stmt_update->close();
} else {
    // Insertar nuevo registro
    $sql_insert = "INSERT INTO artesano (CodArtesano, Descripcion, AniosExp, FechaRegistro, Imagen, CodComunidad) VALUES (?, ?, ?, NOW(), ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    $stmt_insert->bind_param("isiss", $cod_artesano, $descripcion, $anios_exp, $imagen_ruta, $cod_comunidad);

    if ($stmt_insert->execute()) {
        echo "<script>alert('Datos del artesano guardados correctamente'); window.location.href = '../views/subir_producto.php';</script>";
    } else {
        echo "<script>alert('Error al guardar los datos'); window.location.href = '../views/completar_datos_artesano.php';</script>";
    }

    $stmt_insert->close();
}

$stmt_check->close();
$conn->close();
?>
