<?php
include 'db_connection.php';

// Verificar que el usuario tenga el rol de artesano
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'artesano') {
    echo "<script>
              alert('No tienes el rol de Artesano');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener el nombre del producto a eliminar
$nombre_producto = $_POST['nombre_producto'];

// Preparar la consulta SQL para eliminar el producto por nombre
$sql = "DELETE FROM producto WHERE Nombre = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nombre_producto);

if ($stmt->execute()) {
    echo "<script>alert('Producto eliminado correctamente'); window.location.href = '../views/productos/index.html';</script>";
} else {
    echo "<script>alert('Error al eliminar el producto'); window.location.href = '../views/subir_producto.php';</script>";
}

$stmt->close();
$conn->close();
?>
