<?php
include '../controllers/db_connection.php';

// Verificar que el usuario tenga el rol de artesano
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'artesano') {
    echo "<script>
              alert('No tienes el rol de Artesano');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener la lista de comunidades desde la base de datos
$sql_comunidades = "SELECT CodComunidad, Nombre FROM comunidad";
$result_comunidades = $conn->query($sql_comunidades);

// Verificar si hay comunidades disponibles
if ($result_comunidades->num_rows == 0) {
    echo "<script>
              alert('No hay comunidades disponibles. Contacta al administrador.');
              window.location.href = 'subir_producto.php';
          </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Completar Datos Artesano</title>
</head>
<body>
    <h2>Completar Datos del Artesano</h2>
    <form action="../controllers/procesar_datos_artesano.php" method="POST" enctype="multipart/form-data">

        <label for="foto_perfil">Foto de perfil:</label>
        <input type="file" id="foto_perfil" name="foto_perfil" accept="image/*" required><br>

        <label for="descripcion">Descripción:</label><br>
        <textarea name="descripcion" id="descripcion" required></textarea><br>

        <label for="anios_exp">Años de experiencia:</label><br>
        <input type="number" name="anios_exp" id="anios_exp" required><br>

        <label for="cod_comunidad">Comunidad:</label><br>
        <select name="cod_comunidad" id="cod_comunidad" required>
            <option value="">Seleccione su comunidad</option>
            <?php
            // Mostrar las comunidades disponibles en la lista desplegable
            while ($row = $result_comunidades->fetch_assoc()) {
                echo "<option value='" . $row['CodComunidad'] . "'>" . $row['Nombre'] . "</option>";
            }
            ?>
        </select><br>
        

        <button type="submit">Guardar Datos</button>
    </form>
</body>
</html>

<?php
// Cerrar conexión
$conn->close();
?>

