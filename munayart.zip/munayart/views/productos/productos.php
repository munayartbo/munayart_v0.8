<?php include '../../controllers/db_connection.php'; 

// Establecer conexión con la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "munayart";
$port = "3306";

$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Recibir el parámetro de categoría desde la solicitud GET
$categoria = isset($_GET['categoria']) ? $_GET['categoria'] : '';

// Preparar consulta SQL basada en la categoría recibida
$sql = $categoria ? "SELECT * FROM producto WHERE Tipo = '$categoria'" : "SELECT * FROM producto";

$result = $conn->query($sql);

$productos = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $productos[] = [
            "id" => $row["CodProducto"],
            "titulo" => $row["Nombre"],
            "precio" => $row["Precio"],
            "imagen" => $row["Imagen"],
            "tipo" => $row["Tipo"]
        ];
    }
}

// Cerrar conexión
$conn->close();

// Enviar respuesta como JSON
header('Content-Type: application/json');
echo json_encode($productos);
?>
