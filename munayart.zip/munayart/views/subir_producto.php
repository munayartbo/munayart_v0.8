<?php
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'artesano') {
    echo "<script>
            alert('No tienes el rol de Artesano');
            window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subir Producto - MunayArt</title>
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
    <h2>Subir Producto</h2>
    <form action="../controllers/procesar_subida.php" method="POST" enctype="multipart/form-data">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" required>
            <option value="Aretes">Aretes</option>
            <option value="Cerámica">Cerámica</option>
            <option value="Chompa">Chompa</option>
            <option value="Collar">Collar</option>
        </select><br>

        <label for="precio">Precio:</label>
        <input type="number" id="precio" name="precio" required>

        <label for="material">Material:</label>
        <input type="text" id="material" name="material" required>

        <label for="dimensiones">Dimensiones:</label>
        <input type="text" id="dimensiones" name="dimensiones" required>

        <label for="descripcion">Descripción:</label>
        <input type="text" id="descripcion" name="descripcion" required>

        <label for="imagen">Imagen:</label>
        <input type="file" id="imagen" name="imagen" accept="image/*" required>

        <button type="submit">Subir Producto</button>
    </form>

    
    <h2>Eliminar Producto</h2>
    <!-- Formulario para eliminar un producto por nombre -->
    <form action="../controllers/eliminar_producto.php" method="POST">
        <label for="nombre">Nombre del Producto:</label>
        <input type="text" name="nombre_producto" required><br>
        <input type="submit" value="Eliminar Producto">
    </form>

    <h2>Completar Datos del Artesano</h2>
    <!-- Botón para ir al formulario de completar datos del artesano -->
    <form action="completar_datos_artesano.php" method="GET">
        <button type="submit">Completar Datos Artesano</button>
    </form>
</body>
</html>
